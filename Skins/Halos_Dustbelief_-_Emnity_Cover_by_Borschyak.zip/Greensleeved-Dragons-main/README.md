# Greensleeved-Dragons

 A fork of WinglessWolpertinger's resprite pack for Hideous Destructor, originally made by WinglessWolpertinger and upkept by Ted the Dragon and more.
 Anything bolded in the lists is planned on being replaced in the future.

## Includes

- Peppergrinder, No-Scope-Boss, PBweps, Radtech Weapons, Over/Under, Icarus Innovations, AceCorp and Ugly as Sin resprites.
- Total resprites for most items in vanilla Hideous Destructor.
- Total resprites for most enemies in vanilla Hideous Destructor.
- Blursphere texts and partial brightmap support.
- Updated optic sprites from Accensus and Kris.
- Complete Ted-Tweaks support.

## To-do

- Replace anything I deem unworthy.
- Fix up any potential sprite issues.
- Add new sprites for anything not resprited or re-handed.

## Credits

Sorry in advance if I forgot to credit you, this pack wasn't originally intended for release, otherwise I would have kept track of where I got everything. This pack in general is a mess of cobbled together sprites that I liked.
If there's something you feel is deserving of being credited, please let me know at ted the dragon#2020 on discord.

- The original sprite pack - WinglessWolpertinger
- Hands - Potetobloke's Modern Weapons, recolored
- **Pistol** - Chopblock (From 2048 units of /vr/'s gun mod)
- **Revolver** - DoomNukem, Solid Steak, Accensus
- SMG - XLightningStormL, Reflex sight based on a sprite by osjclatchford
- Hunter - SoniK.O.Fan
- Slayer: Originally by Batandy (?). Edits by ChopBlock223. Longer barrel edit by Accensus.
- **ZM66** - Carrot, God Complex
- Vulcanette - Eriance, Barrels sourced from PB's modern weapons
- Herp - Lister's Simple Doom, unknown. From Icarus' resprite.
- Herp (First Person) - Icarus frankensprite.
- Blooper - SoniK.O.Fan, edits by Accensus and Ted the Dragon
- Rocket Launcher - Eriance, scope based on a sprite by Necronixxus(?)
- Boss - Remington R700 from TG5's PB Hand sprites.
- **Liberator** - DoomNukem pickup sprite to my knowledge, taken from Ace's pack. Held sprites are from Project Brutality 3.0 and made by Metalman and Carrot.
- Thunderbuster - Eriance, slightly edited.
- BFG - SoniK.O.Fan, recolored
- Brontornis - Carbine Dioxide, recolored
- Muzzleflashes (mostly) edited from those found in PB's modern weapons
- Chainsaw - A LegenDoom chainsaw.
- Sigcow Sprites - Drpyspy, ThrashFanBert94 on spriting carnival
- Axe, Sledgehammer, Knife, Kharon, Trog, Otis Hands, Bastard, HLAR, Oddball, Lotus & Wiseau- From TG's edit of PB Modern Resprites, recolored
- Arcanum Book & Hand Sprites - Icarus' Resprite, recolored and slightly edited
- Brightmaps - Kylethedragon, tedthedragon, Icarus, probably more.

Items based on sprites by zrrion the insect, Nmn, Neoworm, Dr_Cosmobyte, Ultra64, DoomNukem, PillowBlaster and some others I'm sure and made by WinglessWolpertinger.

Sprites (Peppergrinder):

- All credits for sprites that came from Peppergrinder can be found here: <https://gitlab.com/hdiscord-saltmines/hd-peppergrinder/-/blob/master/credit>
- All edits to those are by Ted the Dragon, Kyle the Dragon, WinglessWolpertinger and TG5.

Sprites (Monsters):

- Baron of hell: Hellstorm Archon on R667, sprites by Midway, Eriance and Id.
- Cacodemon: Carrier from Clusterfuck. No idea past that.
- Demon: N3ON, Randomons v1.2.5.1.
- **Imp**: Taken from Icarus' resprite, Roach edits. Sprites by Vader to my knowledge.
- Lost Soul: Forgotten One on R667, ID Software created.
- Pain Elemental: Hades Elemental on R667, Eriance made.
- Revenant: Not sure, usually known as the Draugr outside of here. Likely Eriance? Taken from Icarus' resprite.
- Arachnotron: Eriance.
- Cyberdemon: Unsure, from Icarus' resprite. Also in Project Malice.
- Spider Mastermind: Unsure, from Icarus' resprite.
- Nazis: Strife.
- Marines: Strife.
- Mancubus: Eriance.
- **Jackboots**: Unsure, from Icarus' resprite.
- Chaingunners: Unsure, from Icarus' resprite.
- Archvile: Unsure, from Icarus' resprite.
- Revolver Zombiemen: HorrorMovieGuy.

Graphics:

- All the sight edits are by Accensus.
- Title by Kris.

Sounds:

- DSSECRET: Penumbra: Black Plague
- DSARTIFA: Penumbra: Black Plague
- DSSRANK/ABRANK: Metal Gear Solid V: The Phantom Pain
- DSQUOTE: Cave Story
- DSALTERN: AlterniaBound
- medical, herp and ied sounds: Killer7
- flare sound effect: penumbra: overture
- Glowstick sounds: Kris
- Blursphere sounds: uwusphere
- Weapon Sounds: H3VR, EFT for far sounds
