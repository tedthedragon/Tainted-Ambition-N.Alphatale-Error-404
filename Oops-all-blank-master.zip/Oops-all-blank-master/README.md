### Usage
---
- Replacement class is controlled via the `oab_replacement` CVar. It's the class name of the actor that should replace all monsters.
- You can specify several classes that will be picked at random by separating each class with a semicolon. For example, `oab_replacement "painlord;painbringer"`. Spaces are ignored.

### Notes
---
- Yokais, bosses, and Archviles are excluded from this.