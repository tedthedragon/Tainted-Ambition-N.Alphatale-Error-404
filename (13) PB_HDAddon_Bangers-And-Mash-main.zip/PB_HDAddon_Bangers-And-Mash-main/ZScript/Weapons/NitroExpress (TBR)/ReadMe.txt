Hello, Potetobloke here.

	I'm planning to rewrite everything for this, despite me never doing much for 
	this. I'll just put a few guidelines here for me to follow. Big thanks to 
	a1337spy for giving me a cool name for it.

	AMMO: .767 Venator Elephantum (roughly translates to Elephant Hunter)
	WEAPON NAME: Mouletta DD-T1 (DD stands for Double Danger)