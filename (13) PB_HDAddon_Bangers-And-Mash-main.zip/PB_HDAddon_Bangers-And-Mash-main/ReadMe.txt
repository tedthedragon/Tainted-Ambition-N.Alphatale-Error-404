You need BulletLib to run this mod.
I'm not particularly active in HDest at the moment, but if you ping me on the HDest Discord, I'll respond to ya.




CREDITS TO EVERYTHING

Mohl - Maintaining and fixing the weapon pack during my absence

---ZScript---
Spawners = Caligari87
Most of the firearms = MatthewTheGlutton

---Melee Stuff---
- Fire Axe -
Sprites = Neoworm
Sounds = Valve
- Pipe Wrench -
Sprites = abbuw
- Knife -
Sprites = Captain J
- Ballistic Shield -
Sprites = Potetobloke
Model = a1337spy

---SP-50 Automag---
Sprites = Bungie
Sounds = Unknown

---M5/165c SMG---
Sprites = Sgt. Shivers, Id Software, Monolith, Banjo Software (Hacx), potetobloke
Sounds = Chronoteeth, Obsidian Entertainment, Unknown
Code Help = Right (From the HDest server)

---Raycob City Killer---
Sprites = Sgt. Shivers
Sounds = Interplay
Code Help = MatthewTheGlutton

---Raycob Exterminator---
Sprites = Chronoteeth, potetobloke
Sounds = Interplay

---RAC-13/9 Machine Pistol---
Sprites = Chronoteeth, SnK (Super Spy), potetobloke
Sounds = Valve

---Heckler & Mok G26A1---
Sprites = Chronoteeth, YukesVonFaust, Chopblock223, potetobloke
Sounds = Black Widow Games (They Hunger)

---L7A1 "Defender"---
Sprites = Chronoteeth, potetobloke
Sounds are a carry over from the A180 (weapon manipulation only)

---Denton Light Arms and Munitions PS-451 Disposable Pistol---
Sprites = Id Software, potetobloke
Sounds = Interplay/Black Isle

---Arkoudi M12/5 Shotgun---
Sprites = LossForWords
Sounds = from base HD

---XM35 Devincenzia---
Sprites = Captain J
Sounds = Mike MacDee (Robocop.pk3)

---Aralite M35A1 HPC---
Sprites = Sgt. Mark IV
Sounds = I forgot :(

---H&M HS776 SmartGun---
Sprites = GAA1992, Mike12/HDoomGuy
Sounds = Valve

---RAT-84---
Sprites = Yukes Von Faust
Sounds = from base HD

---DLAaM APGM-35---
Sprites = Yukes Von Faust
Sounds = from base HD

---Renov OTRU-92---
Sprites = Potetobloke
Sounds = from base HD

---USGI SSW-60---
Sprites = YukesVonFaust, Potetobloke
Sounds = Skulltag(?), CS 1.6


/////UNUSED STUFF/////

---Utsu Denkasou Assault Bracelet (Charge Fist)---
Sprites = Marrub
Sounds = N/A
i havent made it yet
(holy shit is this a lithium cross-over)

---Mouletta DD-T1---
Sprites = Sgt.Shivers
this weapon doesn't work yet ):
as in it won't fire

---Heckler & Mok VP-91 Fusion Pistol---
Sprites = General Tacitus

---MJ12 Energy Projector---
Sprites = Eidos, Deus Ex Wiki

