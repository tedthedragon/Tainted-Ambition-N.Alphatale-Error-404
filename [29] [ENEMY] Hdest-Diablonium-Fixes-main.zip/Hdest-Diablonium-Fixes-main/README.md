# Hdest-Diablonium
Mod for Hideous Destructor, Currently Playable, but very WIP. 

Tested with hdest commit 3b63fb403f (bossbrain: more tweaks.), should work with latest commits. Please do let me know if this breaks. Also willing to accept changes/tweaks.

## Credits

Possessed Skull

Submitted: Jaeden
Decorate: Jaeden
Sounds: ID Software
Sprites: ID Software, Raven
Sprite Edit: Jaeden
Idea Base: Avenged Sevenfold Band Logo

sprites edited by Cryomundus

marbled column

Submitted: Captain Toenail
Decorate: Captain Toenail
Sprites: id Software
Sprite Edit: Captain Toenail, Gez, ShadesMaster, Shtbag667

Wretched

Submitted: KILLA DIO
Code: KILLA DIO, Some death code from Gothic
GLDefs: KILLA DIO
Sounds: KILLA DIO, Freedoom, Librequake (sounds contributed to Librequake by KILLA DIO)
Sprites: 3D Realms
Sprite Edit: KILLA DIO

Deviler Series

Submitted: Doomedarchviledemon
Decorate: Captain Toenail, Doomedarchviledemon
Sprites: Exhumed / Powerslave
Sprite Edits: Doomedarchviledemon
Sounds: Serious Sam, Freesounds
Idea Base: Tremors

hectebus projectiles

Code: AgentSpork, Carnevil, Ghastly
GLDefs: Ghastly Dragon, Sandypaper (Brightmaps)
Sounds: Blizzard Entertainment, Vader, Id Software
Sprites: Id Software, Midway
Sprite Edit: AgentSpork


Latching code taken from babuin.zs from hideousdestructor by Matt, also known as mc776